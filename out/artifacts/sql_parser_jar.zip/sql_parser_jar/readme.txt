input.txt에 변환할 쿼리문을 넣어주시고(sql-sample.txt 파일에 샘플 sql문이 있습니다)
run.bat 파일을 실행해주시면 (안된다면 console에 java -jar sql-parser.jar를 실행하셔도 됩니다)
output.txt에 변환된 값이 json 형식으로 저장됩니다
SQL 문법이 맞지 않거나 변환에 실패한 경우 sql syntax error라는 문구가 output.txt에 저장됩니다